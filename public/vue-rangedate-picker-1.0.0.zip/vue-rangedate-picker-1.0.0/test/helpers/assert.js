import assert from 'assert'

window.assert = assert
